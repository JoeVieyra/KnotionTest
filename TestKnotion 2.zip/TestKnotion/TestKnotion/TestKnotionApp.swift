//
//  TestKnotionApp.swift
//  TestKnotion
//
//  Created by user264681 on 7/5/24.
//

import SwiftUI

@main
struct TestKnotionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
